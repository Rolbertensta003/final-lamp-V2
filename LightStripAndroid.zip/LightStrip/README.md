# Light strip for Android

Android app and home-screen widgets for the ESP32-C3 light strip controller
(firmware v0.1 by Ro-Han G.). It uses the firmware's existing web API, so the
ESP32 needs no changes.

## Build

1. Open this folder in Android Studio (Ladybug 2024.2 or newer).
2. Let Gradle sync. Android Studio downloads Gradle 8.11.1, AGP 8.7.3 and Kotlin 2.1.0.
3. Run on a phone with Android 8.0 or newer that is on the same WiFi as the strip.

Command-line builds need the Gradle wrapper script. Create it once with `gradle wrapper`,
or use Android Studio's Build menu.

## App features

All functions of the web dashboard are included:

- Lamp preview with pull cord, power switch and volume-style brightness
- Colour, warm, cold, pure white, rainbow, blink and music modes, each with its own settings
- On delay and off delay with a live countdown
- OLED note editor (text, font, alignment, show-after time)
- Saved WiFi list (connect, forget, add) and "forget all and restart setup"
- Device details (address, network, signal, sound mode, firmware)

The app also adds:

- Battery percent and voltage in the top bar, on a battery card and on every widget
- Picture upload to the OLED: pick a photo, then it is converted to 128 x 64 with dithering and sent via /api/image
- Automatic discovery when `esp32led.local` does not resolve on the phone
- Talks over WiFi even when Android prefers mobile data, which matters for WiFi without internet

## Widgets

| Widget        | Size  | What it does                                            |
|---------------|-------|---------------------------------------------------------|
| Light switch  | 1 x 1 | Tap to toggle. Glows in the current light colour. Brightness + battery |
| Light status  | 4 x 1 | Mode, brightness minus and plus, battery (tap to refresh) |
| Light modes   | 4 x 2 | All seven modes plus off, power button, battery           |
| Light timers  | 4 x 2 | Off or on in 15 min, 30 min, 1 h or 2 h, cancel, battery  |
| Light battery | 2 x 1 | Battery percent, voltage, level bar, low warning          |

## Background use

On first launch the app asks for notifications (Android 13+) and then shows
Android's "Allow app to run in the background?" dialog. Allowing it means the
system's battery optimisation is turned off for this app. Widgets then refresh:

- right after any widget tap,
- every 15 minutes (WorkManager),
- every 10 to 60 seconds while the screen is on, if "Live widget updates" is
  switched on in Settings. This runs a small foreground service with a notification
  that has Turn on/off and Stop buttons.

Background refresh restarts after a reboot. Some brands (Xiaomi, Huawei, Oppo, Vivo,
Samsung) have their own auto-start lists. Settings has a shortcut to the app info page.

Note: Google Play limits the battery-optimisation permission. This is fine for
personal use and sideloading. Remove the dialog before publishing on Play.

## Project layout

```
app/src/main/java/com/rohang/lightstrip/
  data/        DeviceState (JSON model), LightApi (HTTP), Discovery (mDNS/NSD), Prefs, OledImage
  ui/          Compose screens: main dashboard, settings, components
  widget/      Five widget providers, rendering, button actions
  background/  RefreshWorker, LiveService, BootReceiver, permission helpers
```
