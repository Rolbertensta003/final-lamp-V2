package com.rohang.lightstrip.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.LightApi
import com.rohang.lightstrip.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/** Everything a widget button (or the live notification) can do. */
object WidgetActions {
    const val TOGGLE = "com.rohang.lightstrip.TOGGLE"
    const val BRI_UP = "com.rohang.lightstrip.BRI_UP"
    const val BRI_DOWN = "com.rohang.lightstrip.BRI_DOWN"
    const val MODE = "com.rohang.lightstrip.MODE"
    const val TIMER_OFF = "com.rohang.lightstrip.TIMER_OFF"
    const val TIMER_ON = "com.rohang.lightstrip.TIMER_ON"
    const val TIMER_CANCEL = "com.rohang.lightstrip.TIMER_CANCEL"
    const val REFRESH = "com.rohang.lightstrip.REFRESH"
    const val EXTRA_ARG = "arg"

    private const val BRI_STEP = 26          // about 10 %

    suspend fun perform(ctx: Context, action: String, arg: String?) {
        val api = LightApi(ctx)
        val cur = Prefs.cachedState(ctx)
        try {
            withTimeout(9_000) {
                when (action) {
                    TOGGLE -> {
                        val on = cur?.isOn ?: false
                        cur?.let { optimistic(ctx, it.copy(mode = if (on) "off" else it.last)) }
                        api.set("power=${if (on) 0 else 1}")
                    }
                    BRI_UP, BRI_DOWN -> {
                        val step = if (action == BRI_UP) BRI_STEP else -BRI_STEP
                        val b = ((cur?.bri ?: 128) + step).coerceIn(1, 255)
                        cur?.let { optimistic(ctx, it.copy(bri = b)) }
                        api.set("bri=$b")
                    }
                    MODE -> {
                        val m = arg ?: "off"
                        if (m == "off") {
                            cur?.let { optimistic(ctx, it.copy(mode = "off")) }
                            api.set("power=0")
                        } else {
                            cur?.let { optimistic(ctx, it.copy(mode = m, last = m)) }
                            api.set("mode=$m")
                        }
                    }
                    TIMER_OFF -> api.timer("off", arg?.toIntOrNull() ?: 30)
                    TIMER_ON -> api.timer("on", arg?.toIntOrNull() ?: 30)
                    TIMER_CANCEL -> { api.timer("off", 0); api.timer("on", 0) }
                    else -> api.state(allowDiscovery = false)
                }
                Unit
            }
        } catch (_: Exception) {
            Prefs.setOffline(ctx, true)
            WidgetUpdater.renderAll(ctx)
        }
    }

    /** Draw the expected result right away, the real answer follows a moment later. */
    private fun optimistic(ctx: Context, s: DeviceState) = WidgetUpdater.renderAll(ctx, s, false)
}

class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val arg = intent.getStringExtra(WidgetActions.EXTRA_ARG)
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try { WidgetActions.perform(app, action, arg) } finally { pending.finish() }
        }
    }
}
