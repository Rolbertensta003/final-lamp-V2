package com.rohang.lightstrip.background

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the widget refresh (and live updates, if switched on) after a reboot or app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            Background.sync(context.applicationContext)
        }
    }
}
