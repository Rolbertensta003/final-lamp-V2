package com.rohang.lightstrip.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle
import com.rohang.lightstrip.background.RefreshWorker
import com.rohang.lightstrip.data.LightApi
import com.rohang.lightstrip.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * Shared behaviour of all five widgets: draw the cached state at once,
 * then fetch a fresh one in the background and keep the periodic refresh scheduled.
 */
abstract class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.renderAll(context)
        RefreshWorker.schedule(context)
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                withTimeout(8_000) { LightApi(context).state(allowDiscovery = false) }
            } catch (_: Exception) {
                Prefs.setOffline(context, true)
                WidgetUpdater.renderAll(context)
            } finally {
                pending.finish()
            }
        }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, options: Bundle) {
        WidgetUpdater.renderAll(context)
    }

    override fun onEnabled(context: Context) = RefreshWorker.schedule(context)

    override fun onDisabled(context: Context) {
        if (!WidgetUpdater.hasWidgets(context)) RefreshWorker.cancel(context)
    }
}

class PowerWidget : BaseWidget()
class StatusWidget : BaseWidget()
class ModesWidget : BaseWidget()
class TimerWidget : BaseWidget()
class BatteryWidget : BaseWidget()
