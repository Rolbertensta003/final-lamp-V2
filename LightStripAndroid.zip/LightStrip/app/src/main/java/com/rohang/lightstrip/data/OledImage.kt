package com.rohang.lightstrip.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import kotlin.math.max
import kotlin.math.min

/** Turns any picture into the 128 x 64 one-bit bitmap the OLED shows (/api/image). */
object OledImage {
    const val W = 128
    const val H = 64

    fun load(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 256) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /** fill = crop to fill the screen, otherwise the whole picture fits. */
    fun convert(src: Bitmap, fill: Boolean, dither: Boolean, invert: Boolean, threshold: Int): BooleanArray {
        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(if (invert) Color.WHITE else Color.BLACK)
        val sw = src.width.toFloat()
        val sh = src.height.toFloat()
        val scale = if (fill) max(W / sw, H / sh) else min(W / sw, H / sh)
        val dw = sw * scale
        val dh = sh * scale
        val left = (W - dw) / 2f
        val top = (H - dh) / 2f
        canvas.drawBitmap(src, null, RectF(left, top, left + dw, top + dh), Paint(Paint.FILTER_BITMAP_FLAG))

        val px = IntArray(W * H)
        out.getPixels(px, 0, W, 0, 0, W, H)
        out.recycle()
        val lum = FloatArray(W * H) { i ->
            val p = px[i]
            val l = 0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)
            if (invert) 255f - l else l
        }
        val bits = BooleanArray(W * H)
        for (y in 0 until H) for (x in 0 until W) {
            val i = y * W + x
            val old = lum[i]
            val on = old >= threshold
            bits[i] = on
            if (dither) {                                  // Floyd-Steinberg
                val err = old - if (on) 255f else 0f
                if (x + 1 < W) lum[i + 1] += err * 7 / 16
                if (y + 1 < H) {
                    if (x > 0) lum[i + W - 1] += err * 3 / 16
                    lum[i + W] += err * 5 / 16
                    if (x + 1 < W) lum[i + W + 1] += err * 1 / 16
                }
            }
        }
        return bits
    }

    fun preview(bits: BooleanArray): Bitmap {
        val px = IntArray(W * H) { if (bits[it]) 0xFFEAF1FF.toInt() else 0xFF000000.toInt() }
        return Bitmap.createBitmap(px, W, H, Bitmap.Config.ARGB_8888)
    }

    /** Row by row, leftmost pixel in the high bit: the format of Adafruit drawBitmap(). */
    fun toHex(bits: BooleanArray): String {
        val sb = StringBuilder(W * H / 4)
        for (y in 0 until H) for (bx in 0 until W / 8) {
            var b = 0
            for (k in 0 until 8) if (bits[y * W + bx * 8 + k]) b = b or (0x80 shr k)
            sb.append(HEX[b shr 4]).append(HEX[b and 15])
        }
        return sb.toString()
    }

    private val HEX = "0123456789abcdef".toCharArray()
}
