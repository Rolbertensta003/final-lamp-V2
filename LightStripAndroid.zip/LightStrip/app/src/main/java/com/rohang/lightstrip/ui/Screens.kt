@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.rohang.lightstrip.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rohang.lightstrip.LightViewModel
import com.rohang.lightstrip.background.Background
import com.rohang.lightstrip.data.Prefs
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- root

@Composable
fun LightAppRoot(vm: LightViewModel = viewModel()) {
    val ctx = LocalContext.current
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showIntro by remember { mutableStateOf(!Prefs.onboarded(ctx)) }
    var resumeTick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { resumeTick++ }

    // Poll the strip every 4 s while the app is visible (same rate as the web dashboard)
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) {
        owner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            vm.pollWifi()
            while (true) { vm.poll(); delay(4000) }
        }
    }

    val batteryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { resumeTick++ }
    val askBattery = {
        if (!Background.batteryUnrestricted(ctx)) {
            try { batteryLauncher.launch(Background.batteryIntent(ctx)) }
            catch (_: Exception) { try { batteryLauncher.launch(Background.batterySettingsIntent()) } catch (_: Exception) {} }
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        resumeTick++
        askBattery()
    }
    /** Asks Android for notifications (13+) and then for unrestricted background use. */
    val askBackground: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33 && !Background.notificationsAllowed(ctx)) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else askBattery()
    }

    BackHandler(showSettings) { showSettings = false }
    if (showSettings) SettingsScreen(vm, resumeTick, askBackground) { showSettings = false }
    else MainScreen(vm, resumeTick, askBackground) { showSettings = true }

    if (showIntro) {
        AlertDialog(
            onDismissRequest = {},
            icon = { Icon(Icons.Rounded.Widgets, null) },
            title = { Text("Keep the widgets working") },
            text = {
                Text(
                    "The home screen widgets check the light strip in the background. " +
                        "Android may stop that to save battery. Allow background use and notifications " +
                        "so the widgets update smoothly and the live update option can run."
                )
            },
            confirmButton = {
                TextButton(onClick = { Prefs.setOnboarded(ctx); showIntro = false; askBackground() }) { Text("Allow") }
            },
            dismissButton = {
                TextButton(onClick = { Prefs.setOnboarded(ctx); showIntro = false }) { Text("Not now") }
            }
        )
    }
}

// ---------------------------------------------------------------- main screen

@Composable
fun MainScreen(vm: LightViewModel, resumeTick: Int, askBackground: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val s = vm.state
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    val now by produceState(System.currentTimeMillis()) { while (true) { delay(1000); value = System.currentTimeMillis() } }
    val unrestricted = remember(resumeTick) { Background.batteryUnrestricted(ctx) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Light strip", fontWeight = FontWeight.SemiBold)
                        StatusLine(vm.online)
                    }
                },
                actions = {
                    BatteryChip(s)
                    IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Settings") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = pad.calculateTopPadding() + 4.dp, bottom = pad.calculateBottomPadding() + 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (vm.online == false) item { OfflineCard(ctx, vm, onSettings) }
            if (!unrestricted) item { BackgroundCard(askBackground) }
            if (s == null) {
                item {
                    SectionCard("Connecting", "Looking for the light strip at ${Prefs.host(ctx)}") {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            } else {
                item { HeroCard(s, vm) }
                item { BatteryCard(s) }
                item { ModeTiles(s, vm) }
                item { ModePanel(s, vm) }
                item { ScheduleCard(s, now, vm) }
                item { NoteCard(vm) }
                item { PictureCard(s, vm) }
                item { WifiCard(vm) }
                item { DeviceCard(s, vm) }
                item {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Muted("App 1.0, firmware ${s.ver}", Modifier.weight(1f))
                        Muted("Designed by Ro-Han G.")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusLine(online: Boolean?) {
    val (color, text) = when (online) {
        true -> Good to "Online"
        false -> Bad to "Not responding"
        null -> MaterialTheme.colorScheme.onSurfaceVariant to "Connecting"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun OfflineCard(ctx: Context, vm: LightViewModel, onSettings: () -> Unit) {
    SectionCard("Can't reach the light strip", "Tried ${Prefs.host(ctx)}${Prefs.resolvedIp(ctx)?.let { " ($it)" } ?: ""}. Check that the phone is on the same WiFi and the strip is powered.") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::refresh) { Text("Try again") }
            OutlinedButton(onClick = vm::discover, enabled = !vm.discovering) { Text(if (vm.discovering) "Searching" else "Find on network") }
            TextButton(onClick = onSettings) { Text("Settings") }
        }
    }
}

@Composable
private fun BackgroundCard(askBackground: () -> Unit) {
    SectionCard("Allow background use", "Without it Android may pause the widget updates to save battery.") {
        Button(onClick = askBackground) { Text("Allow") }
    }
}

// ---------------------------------------------------------------- settings

@Composable
fun SettingsScreen(vm: LightViewModel, resumeTick: Int, askBackground: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    var host by rememberSaveable { mutableStateOf(Prefs.host(ctx)) }
    var live by remember { mutableStateOf(Prefs.live(ctx)) }
    var interval by remember { mutableIntStateOf(Prefs.liveInterval(ctx)) }
    val unrestricted = remember(resumeTick) { Background.batteryUnrestricted(ctx) }
    val notifications = remember(resumeTick) { Background.notificationsAllowed(ctx) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = pad.calculateTopPadding() + 4.dp, bottom = pad.calculateBottomPadding() + 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SectionCard("Connection", "Name or IP address of the light strip.") {
                    OutlinedTextField(
                        host, { host = it.trim() }, Modifier.fillMaxWidth(),
                        label = { Text("Address") }, singleLine = true,
                        placeholder = { Text(Prefs.DEFAULT_HOST) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done)
                    )
                    Spacer(Modifier.height(6.dp))
                    Muted("Found at: ${Prefs.resolvedIp(ctx) ?: "not found yet"}")
                    Spacer(Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.setHost(host) }) { Text("Save") }
                        OutlinedButton(onClick = vm::discover, enabled = !vm.discovering) {
                            if (vm.discovering) {
                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text("Find on this network")
                        }
                    }
                }
            }
            item {
                SectionCard("First-time WiFi setup", "When the display shows Setup mode, the strip runs its own WiFi network.") {
                    Muted("1. Join the ESP32C3-Setup network on this phone.\n2. Open the setup page and pick your home WiFi.\n3. Reconnect the phone to your home WiFi and come back here.")
                    Spacer(Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { open(ctx, Intent(Settings.ACTION_WIFI_SETTINGS)) }) { Text("WiFi settings") }
                        Button(onClick = { open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.4.1/"))) }) { Text("Open setup page") }
                    }
                }
            }
            item {
                SectionCard("Background and widgets", "Lets the widgets refresh while the app is closed.") {
                    StatusRow("Background use", if (unrestricted) "Allowed" else "Restricted by battery saving", unrestricted)
                    if (!unrestricted) {
                        Button(onClick = askBackground) { Text("Allow background use") }
                        Spacer(Modifier.height(8.dp))
                    }
                    StatusRow("Notifications", if (notifications) "Allowed" else "Off (needed for live updates)", notifications)
                    if (!notifications) {
                        Button(onClick = askBackground) { Text("Allow notifications") }
                        Spacer(Modifier.height(8.dp))
                    }
                    HorizontalDivider(Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    SwitchRow("Live widget updates", live) { on ->
                        live = on
                        Prefs.setLive(ctx, on)
                        if (on) { if (!notifications || !unrestricted) askBackground(); Background.startLive(ctx) }
                        else Background.stopLive(ctx)
                    }
                    Muted("Keeps widgets current within seconds, including changes from the knob, claps and timers. Shows a small notification and pauses while the screen is off. When off, widgets refresh every 15 minutes and after every tap.")
                    if (live) {
                        Spacer(Modifier.height(12.dp))
                        Text("Check every", fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        Segmented(listOf("10 s" to 10, "15 s" to 15, "30 s" to 30, "60 s" to 60), interval, {
                            interval = it
                            Prefs.setLiveInterval(ctx, it)
                        }, Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(12.dp))
                    Muted("Some phones (Xiaomi, Huawei, Oppo, Vivo, Samsung) also have their own auto-start or app sleep lists. If widgets still stop updating, allow the app there.")
                    TextButton(onClick = { open(ctx, Background.appInfoIntent(ctx)) }, contentPadding = PaddingValues(0.dp)) { Text("Open app info") }
                }
            }
            item {
                SectionCard("Widgets", "Long press the home screen, choose Widgets and find Light strip.") {
                    WidgetLine("Light switch", "1 x 1. Tap to turn on or off. Brightness and battery.")
                    WidgetLine("Light status", "4 x 1. Mode, brightness buttons and battery.")
                    WidgetLine("Light modes", "4 x 2. All seven modes plus off, with battery.")
                    WidgetLine("Light timers", "4 x 2. Off or on in 15 min to 2 hours, with battery.")
                    WidgetLine("Light battery", "2 x 1. Battery percent, voltage and level bar.")
                }
            }
            item {
                SectionCard("About") {
                    Text("Light strip app 1.0", fontWeight = FontWeight.Medium)
                    Muted("For the ESP32-C3 light strip controller. Designed by Ro-Han G.")
                }
            }
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, Modifier.size(18.dp), tint = if (ok) Good else Bad)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, fontWeight = FontWeight.Medium)
            Muted(value)
        }
    }
}

@Composable
private fun WidgetLine(name: String, text: String) {
    Column(Modifier.padding(bottom = 10.dp)) {
        Text(name, fontWeight = FontWeight.Medium)
        Muted(text)
    }
}

private fun open(ctx: Context, intent: Intent) {
    try { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}
