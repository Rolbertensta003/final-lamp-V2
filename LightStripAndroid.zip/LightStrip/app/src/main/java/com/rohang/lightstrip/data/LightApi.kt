package com.rohang.lightstrip.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.rohang.lightstrip.widget.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.URL
import java.net.URLEncoder

/** The strip answered, but refused the request (for example a bad picture size). */
class ApiException(message: String) : Exception(message)

/**
 * HTTP client for the firmware's web API. Every successful state response is
 * cached and pushed to the home screen widgets, so the app, widgets and
 * background work always share the same picture of the light.
 */
class LightApi(context: Context) {
    private val ctx = context.applicationContext

    // ---------------- state and light control ----------------
    suspend fun state(allowDiscovery: Boolean = true) = handleState(call("/api/state", null, allowDiscovery))
    suspend fun set(query: String) = handleState(call("/api/set?$query", null))
    suspend fun timer(type: String, minutes: Int) = handleState(call("/api/timer?type=$type&min=$minutes", null))

    // ---------------- OLED note and picture ----------------
    suspend fun saveNote(text: String, font: Int, align: Int, idle: Int) = handleState(
        call("/api/note", form("text" to text, "font" to "$font", "align" to "$align", "idle" to "$idle"))
    )
    suspend fun sendImage(hex: String) = handleState(call("/api/image", form("bmp" to hex)))
    suspend fun clearImage() = handleState(call("/api/image", form("clear" to "1")))

    // ---------------- saved WiFi ----------------
    suspend fun wifiList() = WifiList.parse(call("/api/wifi", null))
    suspend fun addWifi(ssid: String, pass: String) = WifiList.parse(call("/api/wifi/add", form("ssid" to ssid, "pass" to pass)))
    suspend fun forgetWifi(ssid: String) = WifiList.parse(call("/api/wifi/forget", form("ssid" to ssid)))
    suspend fun connectWifi(ssid: String) = WifiList.parse(call("/api/wifi/connect", form("ssid" to ssid)))
    suspend fun wifiReset() { call("/api/wifireset", null) }

    // ---------------- internals ----------------
    private fun handleState(text: String): DeviceState {
        val s = DeviceState.parse(text, System.currentTimeMillis())
        val old = Prefs.cachedState(ctx)
        val wasOffline = Prefs.offline(ctx)
        Prefs.saveState(ctx, text, s.fetchedAt)
        Prefs.setOffline(ctx, false)
        if (wasOffline || old?.widgetKey() != s.widgetKey()) WidgetUpdater.renderAll(ctx, s, false)
        return s
    }

    private suspend fun call(path: String, body: String?, allowDiscovery: Boolean = true): String =
        withContext(Dispatchers.IO) {
            val host = Prefs.host(ctx)
            val net = wifiNetwork()
            val localName = host.endsWith(".local", ignoreCase = true)
            val targets = LinkedHashSet<String>()
            if (localName) Prefs.resolvedIp(ctx)?.let { targets += it }
            targets += host

            var last: IOException? = null
            for (t in targets) {
                try { return@withContext request(net, t, path, body) } catch (e: IOException) { last = e }
            }
            if (allowDiscovery && localName) {
                val ip = Discovery.find(ctx, host.removeSuffix(".local"))
                if (ip != null) {
                    Prefs.setResolvedIp(ctx, ip)
                    return@withContext request(net, ip, path, body)
                }
            }
            throw last ?: IOException("The light strip is not reachable")
        }

    /**
     * The WiFi network, used even when Android prefers mobile data because the
     * WiFi has no internet (the case for the setup portal and many home LANs).
     */
    private fun wifiNetwork(): Network? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return null
        @Suppress("DEPRECATION")
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    private fun resolve(net: Network?, target: String): String {
        if (!target.endsWith(".local", ignoreCase = true)) return target
        val all = net?.getAllByName(target) ?: InetAddress.getAllByName(target)
        val a = all.firstOrNull { it is Inet4Address } ?: all.firstOrNull() ?: throw IOException("No address for $target")
        val ip = a.hostAddress ?: throw IOException("No address for $target")
        if (a is Inet4Address) Prefs.setResolvedIp(ctx, ip)
        return if (a is Inet6Address) "[${ip.substringBefore('%')}]" else ip
    }

    private fun request(net: Network?, target: String, path: String, body: String?): String {
        val url = URL("http://${resolve(net, target)}$path")
        val conn = (net?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
        try {
            conn.connectTimeout = 3000
            conn.readTimeout = 5000
            conn.useCaches = false
            conn.setRequestProperty("Connection", "close")
            if (body != null) {
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).optString("error") } catch (_: Exception) { "" }
                throw ApiException(msg.ifEmpty { "The light strip answered with error $code" })
            }
            return text
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        fun enc(v: String): String = URLEncoder.encode(v, "UTF-8")
        fun form(vararg p: Pair<String, String>) = p.joinToString("&") { "${it.first}=${enc(it.second)}" }
    }
}
