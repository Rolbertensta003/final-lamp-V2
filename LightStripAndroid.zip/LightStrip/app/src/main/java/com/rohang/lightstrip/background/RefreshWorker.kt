package com.rohang.lightstrip.background

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rohang.lightstrip.data.LightApi
import com.rohang.lightstrip.data.Prefs
import com.rohang.lightstrip.widget.WidgetUpdater
import java.util.concurrent.TimeUnit

/** Refreshes the widgets every 15 minutes (the shortest period Android allows). */
class RefreshWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (!WidgetUpdater.hasWidgets(ctx)) return Result.success()
        try {
            LightApi(ctx).state(allowDiscovery = true)
        } catch (_: Exception) {
            Prefs.setOffline(ctx, true)
            WidgetUpdater.renderAll(ctx)
        }
        return Result.success()
    }

    companion object {
        private const val NAME = "widget_refresh"

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(ctx: Context) = WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
    }
}
