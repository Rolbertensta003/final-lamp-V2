@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.rohang.lightstrip.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rohang.lightstrip.LightViewModel
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.MODE_TITLES
import java.util.Locale
import kotlin.math.roundToInt

// ---------------------------------------------------------------- hero

@Composable
fun HeroCard(s: DeviceState, vm: LightViewModel) {
    SectionCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            LampPreview(s, vm::togglePower, Modifier.size(width = 140.dp, height = 162.dp))
            Spacer(Modifier.weight(1f))
            VerticalBrightness(s.bri, vm::setBrightness)
        }
        Spacer(Modifier.height(16.dp))
        Text(s.title, fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
        Spacer(Modifier.height(4.dp))
        Text(s.detail(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = s.isOn, onCheckedChange = { vm.togglePower() })
            Spacer(Modifier.width(12.dp))
            Text(if (s.isOn) "On" else "Off", fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(8.dp))
            Muted("or tap the lamp")
        }
    }
}

// ---------------------------------------------------------------- battery

@Composable
fun BatteryCard(s: DeviceState) {
    SectionCard(
        title = "Battery",
        subtitle = if (s.bok) "Measured by the strip" else "No battery detected on the strip",
        action = { BatteryChip(s) }
    ) {
        if (s.bok) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${s.bp}%", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = if (s.batteryLow) Bad else MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.width(10.dp))
                Text(s.voltText, Modifier.padding(bottom = 7.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (s.batteryLow) {
                    Spacer(Modifier.width(10.dp))
                    Text("Low, charge soon", Modifier.padding(bottom = 7.dp), color = Bad, fontWeight = FontWeight.Medium)
                }
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { s.bp / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = if (s.batteryLow) Bad else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.outlineVariant,
                drawStopIndicator = {}
            )
        } else {
            Muted("Connect a cell to the divider on GPIO2 to see its level here and on the widgets.")
        }
    }
}

// ---------------------------------------------------------------- modes

private val TILE_NAMES = mapOf(
    "color" to "Colour", "warm" to "Warm", "cold" to "Cold", "white" to "White",
    "rainbow" to "Rainbow", "blink" to "Blink", "music" to "Music"
)

private val TILE_SUBS = mapOf(
    "color" to "Any hue", "warm" to "1800 to 3500 K", "cold" to "5000 to 10000 K", "white" to "All channels",
    "rainbow" to "Moving spectrum", "blink" to "On and off", "music" to "Kick, snare, hi-hat and bass each light up differently"
)

@Composable
private fun ModeTile(s: DeviceState, mode: String, onClick: () -> Unit, modifier: Modifier = Modifier, wide: Boolean = false) {
    val active = s.mode == mode
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (active) 2.dp else 1.dp, if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
    ) {
        val dot = @Composable {
            Box(
                Modifier.size(22.dp).clip(CircleShape).background(modeBrush(s, mode))
                    .border(1.dp, Color.Black.copy(alpha = 0.08f), CircleShape)
            )
        }
        if (wide) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                dot()
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(MODE_TITLES[mode]!!, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Muted(TILE_SUBS[mode]!!)
                }
            }
        } else {
            Column(Modifier.padding(14.dp)) {
                dot()
                Spacer(Modifier.height(12.dp))
                Text(TILE_NAMES[mode]!!, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                Text(TILE_SUBS[mode]!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
fun ModeTiles(s: DeviceState, vm: LightViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf(listOf("color", "warm", "cold"), listOf("white", "rainbow", "blink")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { m -> ModeTile(s, m, { vm.setMode(m) }, Modifier.weight(1f)) }
            }
        }
        ModeTile(s, "music", { vm.setMode("music") }, Modifier.fillMaxWidth(), wide = true)
    }
}

// ---------------------------------------------------------------- mode panels

@Composable
fun ModePanel(s: DeviceState, vm: LightViewModel) {
    when (if (s.mode == "off") s.last else s.mode) {
        "color" -> SectionCard("Colour", "Choose any colour, or start from a swatch.") {
            ColourPicker(s.r, s.g, s.b) { r, g, b -> vm.setColour("color", r, g, b) }
        }
        "warm" -> SectionCard("Warm white", "Lower values feel like candlelight, higher like a classic bulb.") {
            LabelValue("Tone", "${s.warm} K")
            GradientSlider(
                (s.warm - 1800) / 1700f,
                listOf(Color(0xFFFF7E00), Color(0xFFFFA54F), Color(0xFFFFC489)),
                { f -> vm.setWarm(((1800 + f * 1700) / 50f).roundToInt() * 50) },
                label = "Warm tone"
            )
            ChoiceChips(listOf("Candle" to 1900, "Evening" to 2400, "Soft" to 2700, "Studio" to 3200), s.warm, vm::setWarm)
        }
        "cold" -> SectionCard("Cold white", "Crisp light for focus. Higher values turn slightly blue.") {
            LabelValue("Tone", "${s.cold} K")
            GradientSlider(
                (s.cold - 5000) / 5000f,
                listOf(Color(0xFFFFE4CE), Color(0xFFF3F2FF), Color(0xFFC9DAFF)),
                { f -> vm.setCold(((5000 + f * 5000) / 100f).roundToInt() * 100) },
                label = "Cold tone"
            )
            ChoiceChips(listOf("Neutral" to 5000, "Daylight" to 5600, "Cool" to 6500, "Overcast" to 8000), s.cold, vm::setCold)
        }
        "white" -> SectionCard("Pure white", "Red, green and blue at full level.") {
            NoteBox("This is the brightest setting and draws the most power. Use the brightness control to soften it.")
        }
        "rainbow" -> SectionCard("Rainbow", "The full spectrum flows along the strip.") {
            LabelValue("Speed", "${s.speed}")
            SyncSlider(s.speed.toFloat(), 1f..100f, 98, { vm.setSpeed(it.roundToInt()) })
            ChoiceChips(listOf("Drift" to 8, "Gentle" to 35, "Lively" to 70, "Fast" to 100), s.speed, vm::setSpeed)
        }
        "blink" -> SectionCard("Blink", "Flashes one colour on a steady rhythm.") {
            ColourPicker(s.r, s.g, s.b) { r, g, b -> vm.setColour("blink", r, g, b) }
            Spacer(Modifier.height(16.dp))
            LabelValue("On for", secs(s.onMs))
            SyncSlider(s.onMs.toFloat(), 50f..3000f, 58, { vm.setBlink(on = (it / 50f).roundToInt() * 50) })
            LabelValue("Off for", secs(s.offMs))
            SyncSlider(s.offMs.toFloat(), 50f..3000f, 58, { vm.setBlink(off = (it / 50f).roundToInt() * 50) })
            ChoiceChips(
                listOf("Quick" to (150 to 150), "Steady" to (500 to 500), "Slow" to (1200 to 1200), "Beacon" to (100 to 1400)),
                s.onMs to s.offMs,
                onSelect = { (on, off) -> vm.setBlink(on, off) }
            )
        }
        "music" -> SectionCard("Music", "Kick flashes the whole strip in this colour. Snare bursts from the centre, hi-hats sparkle, and sustained bass glows.") {
            ColourPicker(s.r, s.g, s.b) { r, g, b -> vm.setColour("music", r, g, b) }
            Spacer(Modifier.height(16.dp))
            NoteBox("Place the microphone near the speaker. Works best with electronic music, dubstep and beatbox.")
        }
    }
}

private fun secs(ms: Int) = String.format(Locale.US, "%.2f", ms / 1000f).trimEnd('0').trimEnd('.') + " s"

// ---------------------------------------------------------------- schedule

fun formatCountdown(sec: Int): String {
    val h = sec / 3600
    val m = sec % 3600 / 60
    val x = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, x) else String.format(Locale.US, "%d:%02d", m, x)
}

@Composable
fun ScheduleCard(s: DeviceState, now: Long, vm: LightViewModel) {
    SectionCard("Schedule", "Turn the light on or off after a delay.") {
        TimerRow("On delay", "until the light turns on", s.onLeft(now), if (s.onTotal > 0) s.onTotal else s.onT) { vm.timer("on", it) }
        HorizontalDivider(Modifier.padding(vertical = 18.dp), color = MaterialTheme.colorScheme.outlineVariant)
        TimerRow("Off delay", "until the light turns off", s.offLeft(now), if (s.offTotal > 0) s.offTotal else s.offT) { vm.timer("off", it) }
    }
}

@Composable
private fun TimerRow(title: String, caption: String, left: Int, total: Int, onSet: (Int) -> Unit) {
    var custom by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        if (left > 0) TextButton(onClick = { onSet(0) }) { Text("Cancel") }
    }
    if (left > 0) {
        Text(formatCountdown(left), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { if (total > 0) left / total.toFloat() else 0f },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
            trackColor = MaterialTheme.colorScheme.outlineVariant,
            drawStopIndicator = {}
        )
        Spacer(Modifier.height(6.dp))
        Muted(caption)
    } else {
        Spacer(Modifier.height(8.dp))
        ChoiceChips(listOf("15 min" to 15, "30 min" to 30, "1 hour" to 60, "2 hours" to 120), null, onSet)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            val start = { custom.toIntOrNull()?.takeIf { it in 1..1440 }?.let { onSet(it); custom = "" } }
            OutlinedTextField(
                value = custom,
                onValueChange = { v -> custom = v.filter(Char::isDigit).take(4) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Minutes") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { start() })
            )
            Spacer(Modifier.width(10.dp))
            Button(onClick = { start() }, enabled = (custom.toIntOrNull() ?: 0) in 1..1440) { Text("Start") }
        }
    }
}
