package com.rohang.lightstrip.data

import org.json.JSONObject
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/** Light modes in the order the firmware knows them (without "off"). */
val MODES = listOf("color", "warm", "cold", "white", "rainbow", "blink", "music")

val MODE_TITLES = mapOf(
    "off" to "Off", "color" to "Colour", "warm" to "Warm white", "cold" to "Cold white",
    "white" to "Pure white", "rainbow" to "Rainbow", "blink" to "Blink", "music" to "Music"
)

/** Mirror of the JSON returned by /api/state on the ESP32. */
data class DeviceState(
    val ver: String = "",
    val mode: String = "off",
    val last: String = "color",
    val sys: String = "auto",
    val r: Int = 255, val g: Int = 255, val b: Int = 255,
    val bri: Int = 128,
    val warm: Int = 2700, val cold: Int = 6500,
    val speed: Int = 40,
    val onMs: Int = 500, val offMs: Int = 500,
    val onT: Int = 0, val onTotal: Int = 0,
    val offT: Int = 0, val offTotal: Int = 0,
    val note: String = "", val nfont: Int = 3, val nalign: Int = 1, val nidle: Int = 20,
    val img: Boolean = false,
    val ssid: String = "", val ip: String = "", val host: String = "esp32led",
    val bok: Boolean = false, val bv: Double = 0.0, val bp: Int = 0,
    val rssi: Int = 0,
    val fetchedAt: Long = System.currentTimeMillis()
) {
    val isOn get() = mode != "off"
    val briPct get() = max(1, (bri / 2.55).roundToInt())
    val title get() = MODE_TITLES[mode] ?: mode
    val hex get() = String.format(Locale.US, "#%02X%02X%02X", r, g, b)
    val batteryLow get() = bok && bp <= 15
    val batteryText get() = if (bok) "$bp%" else "--"
    val voltText get() = if (bok) String.format(Locale.US, "%.2f V", bv) else ""
    val signal get() = when { rssi > -60 -> "Strong"; rssi > -72 -> "Good"; rssi > -82 -> "Fair"; else -> "Weak" }

    fun onEndsAt(): Long? = if (onT > 0) fetchedAt + onT * 1000L else null
    fun offEndsAt(): Long? = if (offT > 0) fetchedAt + offT * 1000L else null
    fun onLeft(now: Long) = onEndsAt()?.let { max(0, ((it - now) / 1000).toInt()) } ?: 0
    fun offLeft(now: Long) = offEndsAt()?.let { max(0, ((it - now) / 1000).toInt()) } ?: 0

    fun detail(): String {
        val p = "$briPct% brightness"
        return when (mode) {
            "off" -> "Tap the lamp or use the switch to turn it on"
            "color" -> "$hex, $p"
            "warm" -> "$warm K, $p"
            "cold" -> "$cold K, $p"
            "rainbow" -> "Speed $speed, $p"
            "music" -> "Kick, snare, hi-hat and bass, $p"
            "blink" -> "${secs(onMs)} on, ${secs(offMs)} off"
            else -> p
        }
    }

    /** Only the parts the widgets show; used to skip redundant widget redraws. */
    fun widgetKey(): String =
        "$mode|$last|$bri|$r,$g,$b|$warm|$cold|$bok|$bp|${offEndsAt()?.div(60000)}|${onEndsAt()?.div(60000)}"

    companion object {
        fun parse(text: String, at: Long): DeviceState {
            val j = JSONObject(text)
            return DeviceState(
                ver = j.optString("ver"), mode = j.optString("mode", "off"), last = j.optString("last", "color"),
                sys = j.optString("sys", "auto"),
                r = j.optInt("r", 255), g = j.optInt("g", 255), b = j.optInt("b", 255),
                bri = j.optInt("bri", 128), warm = j.optInt("warm", 2700), cold = j.optInt("cold", 6500),
                speed = j.optInt("speed", 40), onMs = j.optInt("on", 500), offMs = j.optInt("off", 500),
                onT = j.optInt("onT"), onTotal = j.optInt("onTotal"),
                offT = j.optInt("offT"), offTotal = j.optInt("offTotal"),
                note = j.optString("note"), nfont = j.optInt("nfont", 3), nalign = j.optInt("nalign", 1),
                nidle = j.optInt("nidle", 20), img = j.optBoolean("img"),
                ssid = j.optString("ssid"), ip = j.optString("ip"), host = j.optString("host", "esp32led"),
                bok = j.optBoolean("bok"), bv = j.optDouble("bv", 0.0), bp = j.optInt("bp"),
                rssi = j.optInt("rssi"), fetchedAt = at
            )
        }

        private fun secs(ms: Int): String {
            val s = ms / 1000.0
            return (if (s == s.toInt().toDouble()) s.toInt().toString() else String.format(Locale.US, "%.2f", s).trimEnd('0')) + " s"
        }
    }
}

data class WifiNet(val ssid: String, val connected: Boolean)

data class WifiList(val max: Int, val list: List<WifiNet>) {
    companion object {
        fun parse(text: String): WifiList {
            val j = JSONObject(text)
            val arr = j.optJSONArray("list")
            val nets = buildList {
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(WifiNet(o.optString("ssid"), o.optBoolean("connected")))
                }
            }
            return WifiList(j.optInt("max", 5), nets)
        }
    }
}

// ---------- colours (shared by the app and the widgets) ----------

fun argb(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

/** Same formula as the firmware's kelvinToColor(). */
fun kelvinArgb(kelvin: Int): Int {
    val t = kelvin / 100.0
    val r: Double
    val g: Double
    if (t <= 66) { r = 255.0; g = 99.4708025861 * ln(t) - 161.1195681661 }
    else { r = 329.698727446 * (t - 60).pow(-0.1332047592); g = 288.1221695283 * (t - 60).pow(-0.0755148492) }
    val b = when { t >= 66 -> 255.0; t <= 19 -> 0.0; else -> 138.5177312231 * ln(t - 10) - 305.0447927307 }
    fun c(v: Double) = v.roundToInt().coerceIn(0, 255)
    return argb(c(r), c(g), c(b))
}

/** Colour the light has in a given mode. */
fun lightArgb(s: DeviceState, mode: String = s.mode): Int = when (mode) {
    "color", "blink", "music" -> argb(s.r, s.g, s.b)
    "warm" -> kelvinArgb(s.warm)
    "cold" -> kelvinArgb(s.cold)
    "white" -> argb(255, 255, 255)
    "rainbow" -> argb(255, 122, 122)
    else -> argb(237, 237, 234)
}
