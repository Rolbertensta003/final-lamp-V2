package com.rohang.lightstrip

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.rohang.lightstrip.background.Background
import com.rohang.lightstrip.ui.LightAppRoot
import com.rohang.lightstrip.ui.LightTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LightTheme { LightAppRoot() } }
    }

    override fun onStart() {
        super.onStart()
        Background.sync(this)
    }
}
