package com.rohang.lightstrip.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Good = Color(0xFF22A06B)
val Bad = Color(0xFFD14343)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1E293B), onPrimary = Color.White,
    background = Color(0xFFFAFAFA), onBackground = Color(0xFF27272A),
    surface = Color.White, onSurface = Color(0xFF27272A),
    surfaceVariant = Color(0xFFF4F4F2), onSurfaceVariant = Color(0xFF64748B),
    surfaceContainer = Color(0xFFF4F4F2), surfaceContainerHigh = Color(0xFFEFEFEC),
    outline = Color(0xFFD6D6D2), outlineVariant = Color(0xFFE7E7E4),
    secondaryContainer = Color(0xFFE2E8F0), onSecondaryContainer = Color(0xFF1E293B),
    error = Bad
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE2E8F0), onPrimary = Color(0xFF1E293B),
    background = Color(0xFF121316), onBackground = Color(0xFFF4F4F5),
    surface = Color(0xFF1C1D21), onSurface = Color(0xFFF4F4F5),
    surfaceVariant = Color(0xFF2A2B30), onSurfaceVariant = Color(0xFFA1A1AA),
    surfaceContainer = Color(0xFF232428), surfaceContainerHigh = Color(0xFF2A2B30),
    outline = Color(0xFF3F3F46), outlineVariant = Color(0xFF2E2F34),
    secondaryContainer = Color(0xFF334155), onSecondaryContainer = Color(0xFFF1F5F9),
    error = Bad
)

@Composable
fun LightTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors, content = content)
}
