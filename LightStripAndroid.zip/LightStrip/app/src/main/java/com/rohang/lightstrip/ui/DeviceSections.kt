@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.rohang.lightstrip.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rohang.lightstrip.LightViewModel
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.OledImage
import com.rohang.lightstrip.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- OLED note

private val FONTS = listOf("Classic small", "Classic medium", "Classic large", "Sans", "Sans bold", "Serif", "Mono")

/** Rough look of each firmware font, as a share of the screen width (same as the dashboard). */
private data class PreviewFont(val family: FontFamily, val weight: FontWeight, val widthShare: Float, val lineHeight: Float)

private val PREVIEW_FONTS = listOf(
    PreviewFont(FontFamily.Monospace, FontWeight.Bold, 0.074f, 1.28f),
    PreviewFont(FontFamily.Monospace, FontWeight.Bold, 0.148f, 1.15f),
    PreviewFont(FontFamily.Monospace, FontWeight.Bold, 0.22f, 1.1f),
    PreviewFont(FontFamily.SansSerif, FontWeight.Normal, 0.105f, 1.35f),
    PreviewFont(FontFamily.SansSerif, FontWeight.Bold, 0.105f, 1.35f),
    PreviewFont(FontFamily.Serif, FontWeight.Normal, 0.11f, 1.3f),
    PreviewFont(FontFamily.Monospace, FontWeight.Normal, 0.13f, 1.2f),
)

@Composable
fun NoteCard(vm: LightViewModel) {
    val d = vm.note
    SectionCard("Display note", "Shown on the OLED once the knob has been idle for a while.") {
        OledFrame {
            BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
                val f = PREVIEW_FONTS[d.font.coerceIn(0, PREVIEW_FONTS.lastIndex)]
                val size = with(LocalDensity.current) { (maxWidth * f.widthShare).toSp() }
                if (d.text.isEmpty()) {
                    Text("Empty note: the display shows the IP address instead", color = Color(0xFF5B6475), fontSize = 11.sp, textAlign = TextAlign.Center)
                } else {
                    Text(
                        d.text,
                        Modifier.fillMaxWidth(),
                        color = Color(0xFFEAF1FF),
                        fontFamily = f.family,
                        fontWeight = f.weight,
                        fontSize = size,
                        lineHeight = size * f.lineHeight,
                        textAlign = if (d.align == 1) TextAlign.Center else TextAlign.Start,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Clip
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = d.text,
            onValueChange = { vm.editNote(d.copy(text = it)) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Message") },
            placeholder = { Text("Write a short note") },
            minLines = 3,
            supportingText = {
                Row(Modifier.fillMaxWidth()) {
                    Text("Letters, numbers and symbols. Preview is approximate.", Modifier.weight(1f))
                    Text("${d.text.length}/120")
                }
            }
        )
        Spacer(Modifier.height(12.dp))
        Text("Font", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        ChoiceChips(FONTS.mapIndexed { i, n -> n to i }, d.font, { vm.editNote(d.copy(font = it)) })
        Spacer(Modifier.height(12.dp))
        Text("Alignment", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("Left" to 0, "Centre" to 1), d.align, { vm.editNote(d.copy(align = it)) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Text("Show after", fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Segmented(listOf("10 s" to 10, "20 s" to 20, "1 min" to 60, "5 min" to 300), d.idle, { vm.editNote(d.copy(idle = it)) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = vm::saveNote, enabled = !vm.savingNote) { Text("Save to display") }
            if (vm.noteTouched) {
                Spacer(Modifier.width(12.dp))
                Muted("Not saved yet")
            }
        }
    }
}

@Composable
private fun OledFrame(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF101114)).padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.widthIn(max = 320.dp).fillMaxWidth().aspectRatio(2f).background(Color.Black), content = content)
    }
}

// ---------------------------------------------------------------- picture

@Composable
fun PictureCard(s: DeviceState, vm: LightViewModel) {
    val ctx = LocalContext.current
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var fill by remember { mutableStateOf(false) }
    var dither by remember { mutableStateOf(true) }
    var invert by remember { mutableStateOf(false) }
    var threshold by remember { mutableFloatStateOf(128f) }
    var bits by remember { mutableStateOf<BooleanArray?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loadError by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) picked = uri }

    LaunchedEffect(picked) {
        val uri = picked ?: return@LaunchedEffect
        val bmp = withContext(Dispatchers.IO) { try { OledImage.load(ctx, uri) } catch (_: Exception) { null } }
        loadError = bmp == null
        source = bmp
    }
    LaunchedEffect(source, fill, dither, invert, threshold) {
        val src = source ?: return@LaunchedEffect
        val t = threshold.toInt()
        val b = withContext(Dispatchers.Default) { OledImage.convert(src, fill, dither, invert, t) }
        bits = b
        preview = OledImage.preview(b)
    }

    SectionCard(
        "Display picture",
        "Send a 128 x 64 picture to the OLED. It replaces the note until you remove it.",
        action = { if (s.img) AssistChip(onClick = {}, label = { Text("Showing") }) }
    ) {
        OledFrame {
            val p = preview
            if (p != null) {
                Image(
                    p.asImageBitmap(), "Picture preview", Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.None
                )
            } else {
                Text(
                    if (loadError) "That picture could not be opened" else "Choose a picture to preview it here",
                    Modifier.align(Alignment.Center).padding(8.dp),
                    color = Color(0xFF5B6475), fontSize = 11.sp, textAlign = TextAlign.Center
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
            Icon(Icons.Rounded.Image, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (source == null) "Choose picture" else "Choose another")
        }
        if (source != null) {
            Spacer(Modifier.height(14.dp))
            Segmented(listOf("Fit" to false, "Fill" to true), fill, { fill = it }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            SwitchRow("Dither (better for photos)", dither) { dither = it }
            SwitchRow("Invert", invert) { invert = it }
            LabelValue("Threshold", threshold.toInt().toString())
            SyncSlider(threshold, 20f..235f, 0, { threshold = it })
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = { bits?.let { vm.sendImage(OledImage.toHex(it)) } },
                enabled = bits != null && !vm.sendingImage
            ) { Text(if (vm.sendingImage) "Sending" else "Send to display") }
            if (s.img) {
                Spacer(Modifier.width(10.dp))
                TextButton(onClick = vm::clearImage) { Text("Remove picture") }
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------------------------------------------------------------- saved WiFi

@Composable
fun WifiCard(vm: LightViewModel) {
    val list = vm.wifi
    var confirm by remember { mutableStateOf<Pair<String, String>?>(null) }   // action, ssid
    var ssid by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }

    SectionCard(
        "Saved WiFi",
        if (list == null) "Loading" else "${list.list.size} of ${list.max} saved. The strip joins the strongest one when it starts."
    ) {
        if (list != null) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
            ) {
                if (list.list.isEmpty()) Text("No saved networks yet.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                list.list.forEachIndexed { i, n ->
                    if (i > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(n.ssid, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(if (n.connected) "Connected" else "Saved", fontSize = 12.sp, color = if (n.connected) Good else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (!n.connected) TextButton(onClick = { confirm = "connect" to n.ssid }) { Text("Connect") }
                        TextButton(onClick = { confirm = "forget" to n.ssid }) { Text("Forget") }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Add a network", fontWeight = FontWeight.SemiBold)
        Muted("Saved for later. The strip tries it the next time it starts.")
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(ssid, { ssid = it.take(32) }, Modifier.fillMaxWidth(), label = { Text("Network name") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            pass, { pass = it.take(64) }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                IconButton(onClick = { show = !show }) {
                    Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, if (show) "Hide password" else "Show password")
                }
            }
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { val sName = ssid.trim(); vm.addWifi(sName, pass) { ssid = ""; pass = ""; show = false } },
            enabled = ssid.isNotBlank()
        ) { Text("Save network") }
    }

    confirm?.let { (action, name) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (action == "connect") "Join $name?" else "Forget $name?") },
            text = {
                Text(
                    if (action == "connect") "The strip restarts and joins this network. The app reconnects once it is back."
                    else "The strip stays connected until it restarts."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (action == "connect") vm.connectWifi(name) else vm.forgetWifi(name)
                    confirm = null
                }) { Text(if (action == "connect") "Restart and join" else "Forget") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- device info

@Composable
fun DeviceCard(s: DeviceState, vm: LightViewModel) {
    val ctx = LocalContext.current
    var confirmReset by remember { mutableStateOf(false) }
    SectionCard("Device") {
        InfoRow("Address", s.ip.ifEmpty { Prefs.resolvedIp(ctx) ?: "-" })
        InfoRow("Name", "${s.host}.local")
        InfoRow("Network", s.ssid.ifEmpty { "-" })
        InfoRow("Signal", "${s.signal} (${s.rssi} dBm)")
        InfoRow("Sound", if (s.sys == "music") "Beat sync" else "Double clap toggles")
        InfoRow("Battery", if (s.bok) "${s.bp}%, ${s.voltText}${if (s.batteryLow) " (low)" else ""}" else "Not detected")
        InfoRow("Firmware", "Version ${s.ver}")
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { confirmReset = true }, contentPadding = PaddingValues(0.dp)) {
            Text("Forget all WiFi and restart setup", color = Bad)
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Restart in setup mode?") },
            text = { Text("Every saved network is forgotten. Join the ESP32C3-Setup WiFi afterwards to set it up again.") },
            confirmButton = { TextButton(onClick = { vm.resetWifi(); confirmReset = false }) { Text("Forget all", color = Bad) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, Modifier.width(96.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Text(value, Modifier.weight(1f), fontSize = 14.sp, maxLines = 1)
    }
}
