package com.rohang.lightstrip

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rohang.lightstrip.data.ApiException
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.Discovery
import com.rohang.lightstrip.data.LightApi
import com.rohang.lightstrip.data.Prefs
import com.rohang.lightstrip.data.WifiList
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.util.Locale

data class NoteDraft(val text: String, val font: Int, val align: Int, val idle: Int)

class LightViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    private val api = LightApi(app)

    var state by mutableStateOf(Prefs.cachedState(app)); private set
    /** null = still connecting, true = answering, false = not reachable */
    var online by mutableStateOf<Boolean?>(null); private set
    var wifi by mutableStateOf<WifiList?>(null); private set
    var discovering by mutableStateOf(false); private set
    var savingNote by mutableStateOf(false); private set
    var sendingImage by mutableStateOf(false); private set

    var note by mutableStateOf(state?.let { NoteDraft(it.note, it.nfont, it.nalign, it.nidle) } ?: NoteDraft("", 3, 1, 20)); private set
    var noteTouched by mutableStateOf(false); private set

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages = _messages.asSharedFlow()
    private fun say(m: String) { _messages.tryEmit(m) }

    // Light commands are merged while one is in flight (like the web dashboard)
    private var sendJob: Job? = null
    private val pending = LinkedHashMap<String, String>()

    private fun accept(s: DeviceState) {
        state = s
        online = true
        if (!noteTouched) note = NoteDraft(s.note, s.nfont, s.nalign, s.nidle)
    }

    private suspend fun <T> call(block: suspend () -> T): T? = try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: ApiException) {
        online = true
        say(e.message ?: "The light strip refused the request")
        null
    } catch (e: Exception) {
        online = false
        null
    }

    // ---------------- polling ----------------
    suspend fun poll() {
        val s = call { api.state() } ?: return
        if (sendJob?.isActive != true) accept(s)       // a command in flight has newer data
    }
    suspend fun pollWifi() { call { api.wifiList() }?.let { wifi = it } }
    fun refresh() { viewModelScope.launch { poll(); pollWifi() } }

    private fun send(vararg params: Pair<String, Any>) {
        params.forEach { (k, v) -> pending[k] = v.toString() }
        if (sendJob?.isActive == true) return
        sendJob = viewModelScope.launch {
            while (pending.isNotEmpty()) {
                val q = pending.entries.joinToString("&") { "${it.key}=${LightApi.enc(it.value)}" }
                pending.clear()
                val s = call { api.set(q) }
                if (s != null && pending.isEmpty()) accept(s)
            }
        }
    }

    // ---------------- light ----------------
    fun togglePower() {
        val s = state ?: return
        state = s.copy(mode = if (s.isOn) "off" else s.last)
        send("power" to if (s.isOn) 0 else 1)
    }

    fun setMode(m: String) {
        val s = state ?: return
        state = s.copy(mode = m, last = if (m != "off") m else s.last)
        send("mode" to m)
    }

    fun setBrightness(v: Int) {
        val b = v.coerceIn(1, 255)
        if (state?.bri == b) return
        state = state?.copy(bri = b)
        send("bri" to b)
    }

    fun setColour(mode: String, r: Int, g: Int, b: Int) {
        val s = state ?: return
        state = s.copy(mode = mode, last = mode, r = r, g = g, b = b)
        send("mode" to mode, "c" to String.format(Locale.US, "%02X%02X%02X", r, g, b))
    }

    fun setWarm(k: Int) {
        state = state?.copy(mode = "warm", last = "warm", warm = k)
        send("mode" to "warm", "warm" to k)
    }

    fun setCold(k: Int) {
        state = state?.copy(mode = "cold", last = "cold", cold = k)
        send("mode" to "cold", "cold" to k)
    }

    fun setSpeed(v: Int) {
        state = state?.copy(mode = "rainbow", last = "rainbow", speed = v)
        send("mode" to "rainbow", "speed" to v)
    }

    fun setBlink(on: Int? = null, off: Int? = null) {
        val s = state ?: return
        state = s.copy(mode = "blink", last = "blink", onMs = on ?: s.onMs, offMs = off ?: s.offMs)
        val p = mutableListOf<Pair<String, Any>>("mode" to "blink")
        on?.let { p += "on" to it }
        off?.let { p += "off" to it }
        send(*p.toTypedArray())
    }

    fun timer(type: String, minutes: Int) {
        viewModelScope.launch { call { api.timer(type, minutes) }?.let(::accept) }
    }

    // ---------------- OLED ----------------
    fun editNote(d: NoteDraft) {
        val clean = d.text.filter { it == '\n' || it.code in 0x20..0x7E }.take(120)
        note = d.copy(text = clean)
        noteTouched = true
    }

    fun saveNote() {
        if (savingNote) return
        viewModelScope.launch {
            savingNote = true
            val d = note
            call { api.saveNote(d.text, d.font, d.align, d.idle) }?.let {
                noteTouched = false
                accept(it)
                say(if (d.text.isEmpty()) "Saved. The display shows the IP address." else "Saved. Showing on the display now.")
            }
            savingNote = false
        }
    }

    fun sendImage(hex: String) {
        if (sendingImage) return
        viewModelScope.launch {
            sendingImage = true
            call { api.sendImage(hex) }?.let { accept(it); say("Picture sent to the display") }
            sendingImage = false
        }
    }

    fun clearImage() {
        viewModelScope.launch { call { api.clearImage() }?.let { accept(it); say("Picture removed, the note is back") } }
    }

    // ---------------- WiFi ----------------
    fun addWifi(ssid: String, pass: String, done: () -> Unit) {
        viewModelScope.launch { call { api.addWifi(ssid, pass) }?.let { wifi = it; say("Saved $ssid"); done() } }
    }

    fun forgetWifi(ssid: String) {
        viewModelScope.launch { call { api.forgetWifi(ssid) }?.let { wifi = it; say("Forgot $ssid") } }
    }

    fun connectWifi(ssid: String) {
        viewModelScope.launch { call { api.connectWifi(ssid) }?.let { wifi = it; say("Restarting to join $ssid") } }
    }

    fun resetWifi() {
        viewModelScope.launch {
            call { api.wifiReset() }?.let { say("WiFi forgotten. The strip restarts in setup mode.") }
        }
    }

    // ---------------- connection settings ----------------
    fun setHost(h: String) {
        Prefs.setHost(ctx, h.trim().ifEmpty { Prefs.DEFAULT_HOST })
        Prefs.setResolvedIp(ctx, null)
        online = null
        refresh()
    }

    fun discover() {
        if (discovering) return
        viewModelScope.launch {
            discovering = true
            val ip = Discovery.find(ctx, Prefs.hostLabel(ctx))
            discovering = false
            if (ip != null) {
                Prefs.setResolvedIp(ctx, ip)
                say("Found the light strip at $ip")
                refresh()
            } else {
                say("No light strip found. Check that the phone is on the same WiFi.")
            }
        }
    }
}
