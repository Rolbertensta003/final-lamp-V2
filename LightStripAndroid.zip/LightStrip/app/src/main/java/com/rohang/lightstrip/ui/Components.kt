@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.rohang.lightstrip.ui

import android.graphics.Color as AColor
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.lightArgb
import java.util.Locale
import kotlin.math.roundToInt

// ---------------------------------------------------------------- cards

@Composable
fun SectionCard(
    title: String? = null,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(20.dp)) {
            if (title != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    action?.invoke()
                }
                Spacer(Modifier.height(16.dp))
            }
            content()
        }
    }
}

@Composable
fun Muted(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
fun NoteBox(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
fun LabelValue(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.Bottom) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Single choice chips that wrap onto several lines. */
@Composable
fun <T> ChoiceChips(options: List<Pair<String, T>>, selected: T?, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (label, value) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
fun <T> Segmented(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    SingleChoiceSegmentedButtonRow(modifier) {
        options.forEachIndexed { i, (label, value) ->
            SegmentedButton(
                selected = value == selected,
                onClick = { onSelect(value) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size)
            ) { Text(label, maxLines = 1) }
        }
    }
}

// ---------------------------------------------------------------- sliders

/** Material slider that keeps its own value while dragged, so polling never makes it jump. */
@Composable
fun SyncSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var local by remember { mutableStateOf<Float?>(null) }
    Slider(
        value = local ?: value.coerceIn(range),
        onValueChange = { local = it; onChange(it) },
        onValueChangeFinished = { local = null },
        valueRange = range,
        steps = steps,
        modifier = modifier
    )
}

/** Slider with a colour gradient track (hue, saturation, colour temperature). value 0..1 */
@Composable
fun GradientSlider(value: Float, colors: List<Color>, onChange: (Float) -> Unit, modifier: Modifier = Modifier, label: String = "") {
    var local by remember { mutableStateOf<Float?>(null) }
    val cb by rememberUpdatedState(onChange)
    val v = (local ?: value).coerceIn(0f, 1f)
    val ring = MaterialTheme.colorScheme.outline
    Canvas(
        modifier
            .fillMaxWidth()
            .height(40.dp)
            .semantics { contentDescription = label }
            .pointerInput(Unit) {
                val r = 14.dp.toPx()
                fun frac(x: Float) = ((x - r) / (size.width - 2 * r)).coerceIn(0f, 1f)
                detectHorizontalDragGestures(
                    onDragStart = { o -> frac(o.x).also { local = it; cb(it) } },
                    onDragEnd = { local = null },
                    onDragCancel = { local = null }
                ) { change, _ -> frac(change.position.x).also { local = it; cb(it) } }
            }
            .pointerInput(Unit) {
                val r = 14.dp.toPx()
                detectTapGestures { o -> cb(((o.x - r) / (size.width - 2 * r)).coerceIn(0f, 1f)) }
            }
    ) {
        val r = 14.dp.toPx()
        val track = 10.dp.toPx()
        drawRoundRect(
            brush = Brush.horizontalGradient(colors, startX = r, endX = size.width - r),
            topLeft = Offset(r, center.y - track / 2),
            size = Size(size.width - 2 * r, track),
            cornerRadius = CornerRadius(track / 2)
        )
        val x = r + v * (size.width - 2 * r)
        drawCircle(Color.White, r - 2.dp.toPx(), Offset(x, center.y))
        drawCircle(ring, r - 2.dp.toPx(), Offset(x, center.y), style = Stroke(1.5.dp.toPx()))
    }
}

/** Volume-style brightness control, like the dashboard. value 1..255 */
@Composable
fun VerticalBrightness(value: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    var local by remember { mutableStateOf<Float?>(null) }
    val cb by rememberUpdatedState(onChange)
    val frac = (local ?: (value / 255f)).coerceIn(0.01f, 1f)
    val shown = (local?.let { (it * 255).roundToInt().coerceAtLeast(1) } ?: value)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${maxOf(1, (shown / 2.55f).roundToInt())}%", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .width(52.dp)
                .height(168.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                .semantics { contentDescription = "Brightness" }
                .pointerInput(Unit) {
                    fun f(y: Float) = (1f - y / size.height).coerceIn(0.01f, 1f)
                    detectVerticalDragGestures(
                        onDragStart = { o -> f(o.y).also { local = it; cb((it * 255).roundToInt()) } },
                        onDragEnd = { local = null },
                        onDragCancel = { local = null }
                    ) { change, _ -> f(change.position.y).also { local = it; cb((it * 255).roundToInt()) } }
                }
                .pointerInput(Unit) {
                    detectTapGestures { o -> cb(((1f - o.y / size.height).coerceIn(0.01f, 1f) * 255).roundToInt()) }
                }
        ) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(frac)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
        Spacer(Modifier.height(8.dp))
        Icon(Icons.Rounded.LightMode, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Muted("Brightness")
    }
}

// ---------------------------------------------------------------- lamp

/** Pendant lamp drawing (same shapes as the dashboard SVG). Tap pulls the cord. */
@Composable
fun LampPreview(s: DeviceState, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val on = s.isOn
    val light by animateColorAsState(Color(lightArgb(s)), tween(500), label = "light")
    val k = s.bri / 255f
    val beam by animateFloatAsState(if (on) 0.12f + 0.6f * k else 0f, tween(500), label = "beam")
    val halo by animateFloatAsState(if (on) 0.14f + 0.3f * k else 0f, tween(500), label = "halo")
    var pulled by remember { mutableStateOf(false) }
    val pull by animateFloatAsState(if (pulled) 10f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "pull")
    LaunchedEffect(pulled) { if (pulled) { kotlinx.coroutines.delay(260); pulled = false } }

    val ink = MaterialTheme.colorScheme.onSurface
    val shade = MaterialTheme.colorScheme.surface
    val highlight = MaterialTheme.colorScheme.outlineVariant
    val bulbOff = MaterialTheme.colorScheme.surfaceVariant

    Canvas(
        modifier
            .semantics { contentDescription = if (on) "Lamp on, tap to turn off" else "Lamp off, tap to turn on" }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                pulled = true; onToggle()
            }
    ) {
        val sx = size.width / 200f
        val sy = size.height / 232f
        withTransform({ scale(sx, sy, pivot = Offset.Zero) }) {
            drawRect(ink, Offset(84f, 0f), Size(32f, 5f))
            drawLine(ink, Offset(100f, 5f), Offset(100f, 54f), 1.25f)
            val beamPath = Path().apply { moveTo(64f, 108f); lineTo(14f, 232f); lineTo(186f, 232f); lineTo(136f, 108f); close() }
            drawPath(beamPath, Brush.verticalGradient(listOf(light.copy(alpha = 0.9f), light.copy(alpha = 0f)), 108f, 232f), alpha = beam)
            drawCircle(light, 30f, Offset(100f, 112f), alpha = halo)
            val dome = Path().apply {
                moveTo(56f, 108f); cubicTo(56f, 76f, 75f, 56f, 100f, 56f); cubicTo(125f, 56f, 144f, 76f, 144f, 108f); close()
            }
            drawPath(dome, shade)
            drawPath(dome, ink, style = Stroke(1.5f))
            val shine = Path().apply { moveTo(70f, 92f); cubicTo(74f, 78f, 84f, 68f, 97f, 65f) }
            drawPath(shine, highlight, style = Stroke(1.5f, cap = StrokeCap.Round))
            drawRoundRect(ink, Offset(94f, 50f), Size(12f, 8f), CornerRadius(2f))
            drawLine(ink, Offset(52f, 108f), Offset(148f, 108f), 1.5f, StrokeCap.Round)
            drawArc(if (on) light else bulbOff, 0f, 180f, true, Offset(87f, 95f), Size(26f, 26f))
            drawArc(ink, 0f, 180f, true, Offset(87f, 95f), Size(26f, 26f), style = Stroke(1f))
            drawLine(ink, Offset(135f, 108f), Offset(135f, 150f + pull), 1f)
            drawCircle(shade, 4.5f, Offset(135f, 155f + pull))
            drawCircle(ink, 4.5f, Offset(135f, 155f + pull), style = Stroke(1.25f))
        }
    }
}

// ---------------------------------------------------------------- battery

fun batteryIcon(s: DeviceState?): ImageVector = when {
    s == null || !s.bok -> Icons.Rounded.BatteryUnknown
    s.batteryLow -> Icons.Rounded.BatteryAlert
    s.bp >= 90 -> Icons.Rounded.BatteryFull
    s.bp >= 50 -> Icons.Rounded.Battery5Bar
    s.bp >= 25 -> Icons.Rounded.Battery3Bar
    else -> Icons.Rounded.Battery1Bar
}

@Composable
fun BatteryChip(s: DeviceState?) {
    val low = s?.batteryLow == true
    val color = if (low) Bad else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(batteryIcon(s), null, Modifier.size(16.dp), tint = color)
        Spacer(Modifier.width(4.dp))
        Text(s?.batteryText ?: "--", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

// ---------------------------------------------------------------- colour picker

private val SWATCHES = listOf(0xFF3B30, 0xFF9500, 0xFFCC00, 0x34C759, 0x00C7BE, 0x0A84FF, 0x5E5CE6, 0xFF2D55, 0xFFFFFF)
private val HUES = listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { Color.hsv(it, 1f, 1f) }

/** Hue and saturation sliders plus quick swatches. Brightness is handled separately. */
@Composable
fun ColourPicker(r: Int, g: Int, b: Int, onPick: (Int, Int, Int) -> Unit) {
    val hsv = remember(r, g, b) { FloatArray(3).also { AColor.RGBToHSV(r, g, b, it) } }
    val hue = hsv[0]
    val sat = hsv[1]
    fun pick(h: Float, s: Float) {
        val c = AColor.HSVToColor(floatArrayOf(h, s, 1f))
        onPick(AColor.red(c), AColor.green(c), AColor.blue(c))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Color(r, g, b))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
        )
        Spacer(Modifier.width(14.dp))
        Text(String.format(Locale.US, "#%02X%02X%02X", r, g, b), fontWeight = FontWeight.Medium)
    }
    Spacer(Modifier.height(12.dp))
    Muted("Hue")
    GradientSlider(hue / 360f, HUES, { pick(it * 360f, if (sat < 0.05f) 1f else sat) }, label = "Hue")
    Muted("Saturation")
    GradientSlider(sat, listOf(Color.White, Color.hsv(hue, 1f, 1f)), { pick(hue, it) }, label = "Saturation")
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        SWATCHES.forEach { c ->
            val rr = (c shr 16) and 0xFF
            val gg = (c shr 8) and 0xFF
            val bb = c and 0xFF
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(Color(rr, gg, bb))
                    .border(1.dp, Color.Black.copy(alpha = 0.1f), CircleShape)
                    .clickable { onPick(rr, gg, bb) }
                    .semantics { contentDescription = String.format(Locale.US, "Colour #%06X", c) }
            )
        }
    }
}

/** Fill used for the little dot on each mode tile. */
fun modeBrush(s: DeviceState, mode: String): Brush =
    if (mode == "rainbow") Brush.sweepGradient(listOf(Color(0xFFFF5E5E), Color(0xFFFFC75E), Color(0xFF7EE081), Color(0xFF5EC8FF), Color(0xFF9B7BFF), Color(0xFFFF5EC4), Color(0xFFFF5E5E)))
    else SolidColor(Color(lightArgb(s, mode)))
