package com.rohang.lightstrip.data

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.Inet4Address
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Finds the strip with Android's network service discovery. The firmware
 * announces "_http._tcp" under its host name (esp32led), so this also works
 * on phones that cannot resolve ".local" names by themselves.
 */
object Discovery {
    suspend fun find(context: Context, label: String, timeoutMs: Long = 7000): String? =
        withContext(Dispatchers.Main) {
            withTimeoutOrNull(timeoutMs) { discover(context.applicationContext, label) }
        }

    private suspend fun discover(ctx: Context, label: String): String? = suspendCancellableCoroutine { cont ->
        val nsd = ctx.getSystemService(NsdManager::class.java)
        val done = AtomicBoolean(false)
        val resolving = AtomicBoolean(false)
        lateinit var listener: NsdManager.DiscoveryListener

        fun finish(ip: String?) {
            if (!done.compareAndSet(false, true)) return
            try { nsd.stopServiceDiscovery(listener) } catch (_: Exception) {}
            if (cont.isActive) cont.resume(ip)
        }

        listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                if (done.compareAndSet(false, true) && cont.isActive) cont.resume(null)
            }
            override fun onServiceFound(info: NsdServiceInfo) {
                val name = info.serviceName ?: return
                if (!name.contains(label, ignoreCase = true) && !name.contains("esp32", ignoreCase = true)) return
                if (!resolving.compareAndSet(false, true)) return
                @Suppress("DEPRECATION")
                nsd.resolveService(info, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) { resolving.set(false) }
                    override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                        @Suppress("DEPRECATION")
                        val addr = serviceInfo.host
                        if (addr is Inet4Address) finish(addr.hostAddress) else resolving.set(false)
                    }
                })
            }
        }

        cont.invokeOnCancellation {
            if (done.compareAndSet(false, true)) try { nsd.stopServiceDiscovery(listener) } catch (_: Exception) {}
        }
        try {
            nsd.discoverServices("_http._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {
            if (done.compareAndSet(false, true) && cont.isActive) cont.resume(null)
        }
    }
}
