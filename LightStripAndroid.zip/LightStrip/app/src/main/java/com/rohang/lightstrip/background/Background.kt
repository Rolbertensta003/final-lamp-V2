package com.rohang.lightstrip.background

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.rohang.lightstrip.data.Prefs
import com.rohang.lightstrip.widget.WidgetUpdater

/** Background permissions and the services that keep the widgets in sync. */
object Background {
    fun batteryUnrestricted(ctx: Context): Boolean =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    fun notificationsAllowed(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Android's own "Allow app to run in the background?" dialog. */
    @SuppressLint("BatteryLife")
    fun batteryIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))

    /** Fallback list screen, for phones that do not offer the dialog. */
    fun batterySettingsIntent(): Intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

    fun appInfoIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))

    /** Called whenever the app comes to the front and after a reboot. */
    fun sync(ctx: Context) {
        if (WidgetUpdater.hasWidgets(ctx)) RefreshWorker.schedule(ctx)
        if (Prefs.live(ctx)) startLive(ctx)
    }

    fun startLive(ctx: Context) {
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, LiveService::class.java)) } catch (_: Exception) {}
    }

    fun stopLive(ctx: Context) {
        ctx.stopService(Intent(ctx, LiveService::class.java))
    }
}
