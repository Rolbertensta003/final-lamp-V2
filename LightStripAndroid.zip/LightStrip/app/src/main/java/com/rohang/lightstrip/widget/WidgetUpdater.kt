package com.rohang.lightstrip.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.text.format.DateFormat
import android.view.View
import android.widget.RemoteViews
import com.rohang.lightstrip.MainActivity
import com.rohang.lightstrip.R
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.Prefs
import com.rohang.lightstrip.data.lightArgb
import java.util.Date

/** Builds the RemoteViews of every widget type and pushes them to the launcher. */
object WidgetUpdater {
    private val providers = listOf(
        PowerWidget::class.java, StatusWidget::class.java, ModesWidget::class.java,
        TimerWidget::class.java, BatteryWidget::class.java
    )

    fun hasWidgets(ctx: Context): Boolean {
        val mgr = AppWidgetManager.getInstance(ctx)
        return providers.any { mgr.getAppWidgetIds(ComponentName(ctx, it)).isNotEmpty() }
    }

    fun renderAll(ctx: Context, state: DeviceState? = Prefs.cachedState(ctx), offline: Boolean = Prefs.offline(ctx)) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        for (cls in providers) {
            val ids = mgr.getAppWidgetIds(ComponentName(app, cls))
            if (ids.isEmpty()) continue
            val views = when (cls) {
                PowerWidget::class.java -> power(app, state, offline)
                StatusWidget::class.java -> status(app, state, offline)
                ModesWidget::class.java -> modes(app, state, offline)
                TimerWidget::class.java -> timer(app, state, offline)
                else -> battery(app, state, offline)
            }
            try { mgr.updateAppWidget(ids, views) } catch (_: Exception) {}
        }
    }

    // ---------------- individual widgets ----------------

    private fun power(ctx: Context, s: DeviceState?, offline: Boolean) = RemoteViews(ctx.packageName, R.layout.widget_power).apply {
        lamp(ctx, this, s)
        setTextViewText(R.id.state, when {
            s == null -> "Set up"
            offline -> "Offline"
            s.isOn -> "${s.briPct}%"
            else -> "Off"
        })
        battery(ctx, this, R.id.battery, s, R.color.w_mute)
        setOnClickPendingIntent(R.id.root, if (s == null) openApp(ctx) else action(ctx, WidgetActions.TOGGLE))
    }

    private fun status(ctx: Context, s: DeviceState?, offline: Boolean) = RemoteViews(ctx.packageName, R.layout.widget_status).apply {
        lamp(ctx, this, s)
        setTextViewText(R.id.title, when {
            s == null -> "Light strip"
            s.isOn -> s.title
            else -> "Light off"
        })
        setTextViewText(R.id.sub, when {
            s == null -> "Open the app to connect"
            offline -> "Offline, tap the battery to retry"
            s.isOn -> "${s.briPct}% brightness"
            else -> "Tap the lamp to turn it on"
        })
        battery(ctx, this, R.id.battery, s, R.color.w_text)
        setOnClickPendingIntent(R.id.info, openApp(ctx))
        setOnClickPendingIntent(R.id.batteryBox, action(ctx, WidgetActions.REFRESH))
        if (s == null) {
            setOnClickPendingIntent(R.id.power, openApp(ctx))
        } else {
            setOnClickPendingIntent(R.id.power, action(ctx, WidgetActions.TOGGLE))
            setOnClickPendingIntent(R.id.minus, action(ctx, WidgetActions.BRI_DOWN))
            setOnClickPendingIntent(R.id.plus, action(ctx, WidgetActions.BRI_UP))
        }
    }

    private val MODE_IDS = linkedMapOf(
        "color" to R.id.m_color, "warm" to R.id.m_warm, "cold" to R.id.m_cold, "white" to R.id.m_white,
        "rainbow" to R.id.m_rainbow, "blink" to R.id.m_blink, "music" to R.id.m_music, "off" to R.id.m_off
    )

    private fun modes(ctx: Context, s: DeviceState?, offline: Boolean) = RemoteViews(ctx.packageName, R.layout.widget_modes).apply {
        setTextViewText(R.id.sub, when {
            s == null -> "Open the app to connect"
            offline -> "Offline"
            s.isOn -> "${s.title}, ${s.briPct}%"
            else -> "Off"
        })
        battery(ctx, this, R.id.battery, s, R.color.w_text)
        setOnClickPendingIntent(R.id.head, openApp(ctx))
        setOnClickPendingIntent(R.id.power, if (s == null) openApp(ctx) else action(ctx, WidgetActions.TOGGLE))
        val textColor = ctx.getColor(R.color.w_text)
        val activeColor = ctx.getColor(R.color.w_on_accent)
        for ((mode, id) in MODE_IDS) {
            val active = s != null && s.mode == mode
            setInt(id, "setBackgroundResource", if (active) R.drawable.widget_btn_active else R.drawable.widget_btn)
            setTextColor(id, if (active) activeColor else textColor)
            setOnClickPendingIntent(id, if (s == null) openApp(ctx) else action(ctx, WidgetActions.MODE, mode))
        }
    }

    private fun timer(ctx: Context, s: DeviceState?, offline: Boolean) = RemoteViews(ctx.packageName, R.layout.widget_timer).apply {
        val fmt = DateFormat.getTimeFormat(ctx)
        val parts = mutableListOf<String>()
        s?.offEndsAt()?.let { parts += "Off at ${fmt.format(Date(it))}" }
        s?.onEndsAt()?.let { parts += "On at ${fmt.format(Date(it))}" }
        setTextViewText(R.id.status, when {
            s == null -> "Open the app to connect"
            offline -> "Offline, timers may be out of date"
            parts.isEmpty() -> "No timer running"
            else -> parts.joinToString(", ")
        })
        setViewVisibility(R.id.cancel, if (parts.isNotEmpty()) View.VISIBLE else View.GONE)
        setOnClickPendingIntent(R.id.cancel, action(ctx, WidgetActions.TIMER_CANCEL))
        battery(ctx, this, R.id.battery, s, R.color.w_text)
        setOnClickPendingIntent(R.id.root, openApp(ctx))
        val minutes = listOf(15, 30, 60, 120)
        val offIds = listOf(R.id.off15, R.id.off30, R.id.off60, R.id.off120)
        val onIds = listOf(R.id.on15, R.id.on30, R.id.on60, R.id.on120)
        for (i in minutes.indices) {
            setOnClickPendingIntent(offIds[i], if (s == null) openApp(ctx) else action(ctx, WidgetActions.TIMER_OFF, "${minutes[i]}"))
            setOnClickPendingIntent(onIds[i], if (s == null) openApp(ctx) else action(ctx, WidgetActions.TIMER_ON, "${minutes[i]}"))
        }
    }

    private fun battery(ctx: Context, s: DeviceState?, offline: Boolean) = RemoteViews(ctx.packageName, R.layout.widget_battery).apply {
        val ok = s?.bok == true
        val low = s?.batteryLow == true
        setTextViewText(R.id.pct, if (ok) "${s!!.bp}%" else if (s == null) "--" else "No battery")
        setTextViewText(R.id.volt, when {
            offline -> "Offline"
            ok -> s!!.voltText
            else -> ""
        })
        setTextColor(R.id.pct, ctx.getColor(if (low) R.color.w_low else R.color.w_text))
        setViewVisibility(R.id.low, if (low) View.VISIBLE else View.GONE)
        setViewVisibility(R.id.bar, if (low) View.GONE else View.VISIBLE)
        setViewVisibility(R.id.barLow, if (low) View.VISIBLE else View.GONE)
        val p = if (ok) s!!.bp else 0
        setProgressBar(R.id.bar, 100, p, false)
        setProgressBar(R.id.barLow, 100, p, false)
        setOnClickPendingIntent(R.id.root, if (s == null) openApp(ctx) else action(ctx, WidgetActions.REFRESH))
    }

    // ---------------- helpers ----------------

    private fun lamp(ctx: Context, v: RemoteViews, s: DeviceState?) {
        val on = s?.isOn == true
        v.setInt(R.id.glow, "setColorFilter", if (on) lightArgb(s!!) else ctx.getColor(R.color.w_btn))
    }

    private fun battery(ctx: Context, v: RemoteViews, id: Int, s: DeviceState?, normalColor: Int) {
        v.setTextViewText(id, when {
            s == null -> "--"
            s.bok -> "${s.bp}%"
            else -> "No batt"
        })
        v.setTextColor(id, ctx.getColor(if (s?.batteryLow == true) R.color.w_low else normalColor))
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun action(ctx: Context, action: String, arg: String? = null): PendingIntent {
        val intent = Intent(ctx, WidgetActionReceiver::class.java).setAction(action).putExtra(WidgetActions.EXTRA_ARG, arg)
        return PendingIntent.getBroadcast(
            ctx, (action + (arg ?: "")).hashCode(), intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
