package com.rohang.lightstrip.data

import android.content.Context

/** Small key-value store shared by the app, the widgets and the background work. */
object Prefs {
    const val DEFAULT_HOST = "esp32led.local"
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("light_prefs", Context.MODE_PRIVATE)

    fun host(c: Context): String = sp(c).getString("host", DEFAULT_HOST) ?: DEFAULT_HOST
    fun hostLabel(c: Context): String = host(c).removeSuffix(".local")
    fun setHost(c: Context, h: String) = sp(c).edit().putString("host", h).apply()

    /** IP found for a ".local" name (mDNS / network discovery). */
    fun resolvedIp(c: Context): String? = sp(c).getString("ip", null)
    fun setResolvedIp(c: Context, ip: String?) = sp(c).edit().putString("ip", ip).apply()

    fun cachedState(c: Context): DeviceState? {
        val p = sp(c)
        val text = p.getString("state", null) ?: return null
        return try { DeviceState.parse(text, p.getLong("state_at", 0)) } catch (_: Exception) { null }
    }
    fun saveState(c: Context, json: String, at: Long) =
        sp(c).edit().putString("state", json).putLong("state_at", at).apply()

    fun offline(c: Context) = sp(c).getBoolean("offline", false)
    fun setOffline(c: Context, v: Boolean) { if (offline(c) != v) sp(c).edit().putBoolean("offline", v).apply() }

    fun onboarded(c: Context) = sp(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context) = sp(c).edit().putBoolean("onboarded", true).apply()

    /** Live widget updates through a foreground service. */
    fun live(c: Context) = sp(c).getBoolean("live", false)
    fun setLive(c: Context, v: Boolean) = sp(c).edit().putBoolean("live", v).apply()
    fun liveInterval(c: Context) = sp(c).getInt("live_interval", 15)
    fun setLiveInterval(c: Context, s: Int) = sp(c).edit().putInt("live_interval", s).apply()
}
