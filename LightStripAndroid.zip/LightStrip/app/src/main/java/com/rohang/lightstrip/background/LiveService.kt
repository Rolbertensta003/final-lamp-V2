package com.rohang.lightstrip.background

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.rohang.lightstrip.MainActivity
import com.rohang.lightstrip.R
import com.rohang.lightstrip.data.DeviceState
import com.rohang.lightstrip.data.LightApi
import com.rohang.lightstrip.data.Prefs
import com.rohang.lightstrip.widget.WidgetActions
import com.rohang.lightstrip.widget.WidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Optional "live widgets" mode. Polls the strip every few seconds while the
 * screen is on, so changes made with the knob, by clapping or by the timers show
 * up on the widgets almost immediately. Pauses while the screen is off.
 */
class LiveService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                Prefs.setLive(this, false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> scope.launch {
                WidgetActions.perform(applicationContext, WidgetActions.TOGGLE, null)
                notifyState()
            }
        }
        goForeground(build(Prefs.cachedState(this)))
        if (loop?.isActive != true) loop = scope.launch { pollLoop() }
        return START_STICKY
    }

    private suspend fun pollLoop() {
        val pm = getSystemService(PowerManager::class.java)
        while (scope.isActive) {
            if (pm.isInteractive) {
                try {
                    LightApi(applicationContext).state(allowDiscovery = false)
                } catch (_: Exception) {
                    if (!Prefs.offline(applicationContext)) {
                        Prefs.setOffline(applicationContext, true)
                        WidgetUpdater.renderAll(applicationContext)
                    }
                }
                notifyState()
            }
            delay(Prefs.liveInterval(applicationContext) * 1000L)
        }
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID, n)
    }

    private fun notifyState() {
        if (!Background.notificationsAllowed(this)) return
        try { NotificationManagerCompat.from(this).notify(ID, build(Prefs.cachedState(this))) } catch (_: SecurityException) {}
    }

    private fun build(s: DeviceState?): Notification {
        val offline = Prefs.offline(this)
        val title = when {
            s == null -> "Light strip"
            offline -> "Light strip offline"
            s.isOn -> "${s.title}, ${s.briPct}%"
            else -> "Light is off"
        }
        val battery = if (s?.bok == true) "Battery ${s.bp}%" else "No battery reading"
        val text = "$battery. Widgets update every ${Prefs.liveInterval(this)} s."
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val toggle = PendingIntent.getService(this, 1, Intent(this, LiveService::class.java).setAction(ACTION_TOGGLE), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, LiveService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_lamp)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, if (s?.isOn == true) "Turn off" else "Turn on", toggle)
            .addAction(0, "Stop live updates", stop)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "live"
        private const val ID = 7
        const val ACTION_STOP = "com.rohang.lightstrip.LIVE_STOP"
        const val ACTION_TOGGLE = "com.rohang.lightstrip.LIVE_TOGGLE"

        fun createChannel(ctx: Context) {
            val ch = NotificationChannel(CHANNEL, "Live widget updates", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shown while the widgets are kept in sync with the light strip"
                setShowBadge(false)
            }
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
}
