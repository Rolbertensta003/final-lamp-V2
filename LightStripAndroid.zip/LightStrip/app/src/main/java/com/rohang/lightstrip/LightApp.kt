package com.rohang.lightstrip

import android.app.Application
import com.rohang.lightstrip.background.LiveService

class LightApp : Application() {
    override fun onCreate() {
        super.onCreate()
        LiveService.createChannel(this)
    }
}
